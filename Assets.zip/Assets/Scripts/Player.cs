using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Player : MonoBehaviour
{
    protected float jump_speed = 9.0f;
    private Rigidbody rb;
    private bool is_landing = false;

   

    // Start is called before the first frame update
    void Start()
    {
        rb = this.GetComponent<Rigidbody>();
        this.is_landing = false;
        
    }

    // Update is called once per frame
    void Update()
    {
        if (this.is_landing)
        {
            if(Input.GetKeyDown(KeyCode.S))
            {
                this.is_landing = false;
                rb.velocity = Vector3.up * this.jump_speed;
            }
        }
    }

    void OnCollisionEnter(Collision coll)
    {
        if(coll.gameObject.CompareTag("Floor"))
        {
            this.is_landing = true;
        }
    }

  
}
