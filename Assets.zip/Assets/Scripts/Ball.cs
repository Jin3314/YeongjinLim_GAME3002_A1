using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class Ball : MonoBehaviour
{
    public bool win = false;
   
    // Start is called before the first frame update
    void Start()
    {
        this.GetComponent<Rigidbody>().velocity = new Vector3(-10.0f, 9.0f, 0.0f);
       
      
    }

    // Update is called once per frame
    void OnBecameInvisible()
    {
        Destroy(this.gameObject);
    }

    void OnCollisionEnter(Collision coll2)
    {
        if (coll2.gameObject.CompareTag("GoalPost"))
        {
            Destroy(this.gameObject);
            GameObject.Find("Canvas").transform.FindChild("GameOverPanel").gameObject.SetActive(true);

            Time.timeScale = 0;
           
        }
        if (coll2.gameObject.CompareTag("Floor"))
        {
            Destroy(this.gameObject);
        }
        if (coll2.gameObject.CompareTag("Player"))
        {
            Score_Manager.score += 1;
        }

    }


}
